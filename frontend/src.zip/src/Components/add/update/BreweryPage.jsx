// import AddBrewery from "./AddBrewery";
// import AddPost from "./AddBeer";
// import Card from "../../../Shared/Card";

// function BreweryPage() {
//   return (
//     <div class="container">
//       <div class="row">
//         <div class="col"></div>
//         <div class="col-5">
//           <Card>
//             <AddBrewery />
//           </Card>
//         </div>
//         <div class="col"></div>
//       </div>
//     </div>
//   );
// }

// export default BreweryPage;
