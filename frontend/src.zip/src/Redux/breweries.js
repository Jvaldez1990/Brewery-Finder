// import * as ActionTypes from "./actionTypes";

// export const Breweries = (state = { breweries: [] }, action) => {
//   console.log(action)
//   switch (action.type) {
//     case ActionTypes.ADD_BREWERY:
//       return { ...state,
//         breweries: action.payload };

//     default:
//       return state;
//   }
// };

// export const Beers =( state = {beers: [] }, action) => {
//   switch(action.type) {
//     case ActionTypes.ADD_BEER:
//       return {...state,
//       beers: action.payload};

//       default:
//         return state;
//   }
// }
