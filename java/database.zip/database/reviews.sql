INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Greatest Beer Ever',
'This is the best beer in the world!',
5,now(), 1);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Not enough Oats',
'I didnt get my oats for this. 4/10 would not reccomend',
2, now(), 1);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('BLM',
'Yes',
5,now(), 2);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Not enough Black',
'I didnt get my Black for this. 4/10 would not reccomend',
2,now(), 2);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Whoops! All Down Under!',
'Pretty good. Not too sweet. Not too salty. I think thats good for a beer, right?',
5,now(), 3);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Not enough down under',
'I didnt get my down for this. 6/10 would not reccomend',
3,now(), 3);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Fills me with Determi-wait, no, Fortitude',
'Seeing an outdated Undertale reference fills me with Fortitude',
4,now(), 4);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Not enough Fortitude',
'I didnt get my fortitude for this. 4/10 would not reccomend',
2,now(), 4);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Brown for sure',
'Beer is brown, sometimes, so thats good, right?',
4,now(), 5);

INSERT INTO reviews (name, description, rating, create_date, beer_id) VALUES
('Not enough dog',
'I didnt get my dog for this. 4/10 would not reccomend',
2,now(), 5);